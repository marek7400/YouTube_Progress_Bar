// injector.js - Działa w świecie MAIN strony YouTube
(function() {
  'use strict';

  /**
   * Pobiera dane o rozdziałach z odtwarzacza YouTube i wysyła je przez postMessage.
   */
  function sendChapterData() {
    try {
      const player = document.querySelector('.html5-video-player');
      // Upewnij się, że odtwarzacz i jego API są dostępne
      if (player && typeof player.getPlayerResponse === 'function') {
        const videoData = player.getPlayerResponse();
        if (videoData && videoData.videoDetails) {
          window.postMessage({
            type: 'FROM_PAGE_SCRIPT_CHAPTER_DATA_YTPB', // Ten sam typ, na który nasłuchuje content.js
            description: videoData.videoDetails.shortDescription,
            durationSeconds: videoData.videoDetails.lengthSeconds,
            videoId: videoData.videoDetails.videoId
          }, '*'); // Wysyłanie do dowolnego źródła w obrębie okna
        } else {
          // console.log('YTPB Injector: videoData or videoDetails not found.');
        }
      } else {
        // console.log('YTPB Injector: Player or getPlayerResponse not found.');
      }
    } catch (e) {
      console.warn('YTPB Injector: Error getting chapter data from page.', e);
    }
  }

  // Nasłuchuj na żądania od content.js
  window.addEventListener('message', function(event) {
    // Akceptuj wiadomości tylko z tego samego okna i o określonym typie
    if (event.source === window && event.data && event.data.type === 'REQUEST_CHAPTER_DATA_YTPB_FROM_CONTENT') {
      sendChapterData();
    }
  });

})();