(function() {
  'use strict';

  let options = {
    enabled: true,
    progressColor: '#F76400',
    progressOpacity: 1,
    bufferColor: '#808080',
    bufferOpacity: 1,
    unbufferedColor: '#000000',
    unbufferedOpacity: 1,
    barHeight: 3,
    zIndex: 60,
    chaptersEnabled: true,
    chapterMarkerColor: '#FFFFFF' // Domyślna wartość, zostanie nadpisana przez chrome.storage.sync.get
  };

  let customBar, progressBar, bufferBar, unbufferedBar;
  let chapterMarkersContainer;
  let currentVideoIdForChapters = null;

  function loadOptions(callback) {
    chrome.storage.sync.get(options, function(items) {
      options = items; // Nadpisuje cały obiekt options, w tym chapterMarkerColor, jeśli jest zapisany
      if (callback) callback();
    });
  }

  function createProgressBar() {
    const player = document.querySelector('.html5-video-player');
    if (!player) return;

    if (customBar) {
        removeProgressBar();
    }

    customBar = document.createElement('div');
    customBar.id = 'custom-progress-bar';

    progressBar = document.createElement('div');
    progressBar.id = 'custom-progress';

    bufferBar = document.createElement('div');
    bufferBar.id = 'custom-buffer';

    unbufferedBar = document.createElement('div');
    unbufferedBar.id = 'custom-unbuffered';

    customBar.appendChild(unbufferedBar);
    customBar.appendChild(bufferBar);
    customBar.appendChild(progressBar);

    if (options.chaptersEnabled) {
        createChapterMarkersContainer();
    }
    player.appendChild(customBar);
    updateStyles();
  }

  function removeProgressBar() {
    if (customBar) {
      customBar.remove();
      customBar = null;
      progressBar = null;
      bufferBar = null;
      unbufferedBar = null;
      chapterMarkersContainer = null;
    }
  }

  function updateProgressBar() {
    if (!options.enabled || !customBar) {
      return;
    }
    const player = document.querySelector('.html5-video-player');
    if (!player) return;
    const video = player.querySelector('video');
    if (!video || isNaN(video.duration)) return;

    const progress = (video.currentTime / video.duration) * 100;
    if (progressBar) progressBar.style.width = `${progress}%`;

    if (video.buffered.length > 0) {
      const bufferedTime = video.buffered.end(video.buffered.length - 1);
      const bufferedPercent = (bufferedTime / video.duration) * 100;
      if (bufferBar) bufferBar.style.width = `${bufferedPercent}%`;
    }
    requestAnimationFrame(updateProgressBar);
  }

  function createChapterMarkersContainer() {
    if (!customBar || chapterMarkersContainer) return;

    chapterMarkersContainer = document.createElement('div');
    chapterMarkersContainer.id = 'custom-chapter-markers';
    chapterMarkersContainer.style.cssText = `
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: ${options.barHeight}px;
        pointer-events: none;
        z-index: ${(parseInt(options.zIndex) || 0) + 3};
    `;
    customBar.appendChild(chapterMarkersContainer);
  }

  function drawChapterMarkersLogic(description, durationSeconds) {
    if (!options.chaptersEnabled || !customBar) {
        if (chapterMarkersContainer) chapterMarkersContainer.innerHTML = '';
        return;
    }
    if (!chapterMarkersContainer) {
        createChapterMarkersContainer();
    }
    if (!chapterMarkersContainer) return;

    chapterMarkersContainer.innerHTML = '';

    if (!description || !durationSeconds || durationSeconds === 0) {
        return;
    }

    const lines = description.split('\n');
    const regex = /((?<h>\d{0,2}):)?(?<m>\d{1,2}):(?<s>\d{2})/;
    const chapterTimestamps = [];

    for (const line of lines) {
        const match = line.match(regex);
        if (match && match.groups) {
            const timestampEndIndex = match.index + match[0].length;
            const potentialChapterTitle = line.substring(timestampEndIndex).trim();
            if (potentialChapterTitle.length > 0 && !/^\d/.test(potentialChapterTitle)) {
                 chapterTimestamps.push(match.groups);
            }
        }
    }

    if (chapterTimestamps.length === 0) return;

    const convertToSeconds = (timeObject) => {
        const h = parseInt(timeObject.h) || 0;
        const m = parseInt(timeObject.m) || 0;
        const s = parseInt(timeObject.s) || 0;
        return h * 3600 + m * 60 + s;
    };

    for (const timeObject of chapterTimestamps) {
        const chapterTimeSeconds = convertToSeconds(timeObject);
        const percent = (chapterTimeSeconds / durationSeconds) * 100;
        if (chapterTimeSeconds === 0 || isNaN(percent) || percent <= 0 || percent >= 100) {
            continue;
        }
        const marker = document.createElement('div');
        marker.className = 'custom-chapter-marker';
        marker.style.cssText = `
            position: absolute;
            left: ${percent}%;
            top: 0;
            width: 2px;
            height: 100%;
            background-color: ${options.chapterMarkerColor}; /* UŻYJ KOLORU Z OPCJI */
            transform: translateX(-50%);
        `;
        chapterMarkersContainer.appendChild(marker);
    }
  }

  // Nasłuchuj wiadomości od injector.js (działającego w MAIN world)
  window.addEventListener('message', function(event) {
      if (event.source === window && event.data && event.data.type === 'FROM_PAGE_SCRIPT_CHAPTER_DATA_YTPB') {
          const { description, durationSeconds, videoId } = event.data;
          if (description && typeof durationSeconds !== 'undefined') {
              currentVideoIdForChapters = videoId;
              drawChapterMarkersLogic(description, parseFloat(durationSeconds));
          }
      }
  });

  function safeDrawChapterMarkers() {
    if (!options.chaptersEnabled || !options.enabled) {
         if (chapterMarkersContainer) chapterMarkersContainer.innerHTML = '';
        return;
    }
    const playerElement = document.querySelector('.html5-video-player');
    if (!playerElement) return;

    // Wyślij żądanie do injector.js (działającego w MAIN world)
    try {
      window.postMessage({ type: 'REQUEST_CHAPTER_DATA_YTPB_FROM_CONTENT' }, '*');
    } catch (e) {
      console.warn('YTPB ContentScript: Could not post message to request chapter data.', e);
    }
  }

  function checkAndAddProgressBar() {
    if (options.enabled) {
      if (!customBar || !document.body.contains(customBar)) {
        createProgressBar();
      }
      updateProgressBar();
      safeDrawChapterMarkers();
    } else {
      removeProgressBar();
    }
  }

  function toHex(opacity) {
    const hex = Math.round(opacity * 255).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }

  function updateStyles() {
    if (!customBar) return;
    customBar.style.cssText = `
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: ${options.barHeight}px;
      z-index: ${options.zIndex};
      display: ${options.enabled ? 'block' : 'none'};
    `;
    if (progressBar) {
      progressBar.style.cssText = `
        width: ${progressBar.style.width || '0%'};
        height: 100%;
        background-color: ${options.progressColor + toHex(options.progressOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${(parseInt(options.zIndex) || 0) + 2};
      `;
    }
    if (bufferBar) {
      bufferBar.style.cssText = `
        width: ${bufferBar.style.width || '0%'};
        height: 100%;
        background-color: ${options.bufferColor + toHex(options.bufferOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${(parseInt(options.zIndex) || 0) + 1};
      `;
    }
    if (unbufferedBar) {
      unbufferedBar.style.cssText = `
        width: 100%;
        height: 100%;
        background-color: ${options.unbufferedColor + toHex(options.unbufferedOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${parseInt(options.zIndex) || 0};
      `;
    }
    if (chapterMarkersContainer) {
        chapterMarkersContainer.style.height = `${options.barHeight}px`;
        chapterMarkersContainer.style.zIndex = (parseInt(options.zIndex) || 0) + 3;
        // Znaczniki zostaną przerysowane z nowym kolorem przez drawChapterMarkersLogic
        // jeśli opcja chapterMarkerColor się zmieniła i RedrawChaptersOnly/RerenderAll jest true
    }
  }

  function initializeExtension() {
    loadOptions(function() {
      const pageObserver = new MutationObserver(mutations => {
        const player = document.querySelector('.html5-video-player');
        if (player && options.enabled && (!customBar || !player.contains(customBar))) {
            checkAndAddProgressBar();
        } else if (!player && customBar) {
            removeProgressBar();
        }
      });
      pageObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      document.addEventListener('yt-navigate-finish', () => {
        currentVideoIdForChapters = null;
        if (chapterMarkersContainer) {
            chapterMarkersContainer.innerHTML = '';
        }
        checkAndAddProgressBar();
      });
      checkAndAddProgressBar();
    });
  }

  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'sync') {
        let RerenderAll = false;
        let RedrawChaptersOnly = false;
        let UpdateStylesOnly = false;

        for (let key in changes) {
            if (options.hasOwnProperty(key)) {
                options[key] = changes[key].newValue; // Aktualizuj lokalny obiekt options
                if (key === 'enabled') {
                    RerenderAll = true;
                } else if (key === 'chaptersEnabled') {
                    if (options.enabled) RerenderAll = true;
                } else if (key === 'chapterMarkerColor') { // Jeśli zmieniono kolor znaczników
                    if (options.enabled && options.chaptersEnabled) RedrawChaptersOnly = true;
                } else { // Inne zmiany (kolory paska, wysokość, opacity, zIndex)
                    if (options.enabled) UpdateStylesOnly = true;
                }
            }
        }

        if (RerenderAll) {
            checkAndAddProgressBar(); // To powinno również przerysować znaczniki z nowym kolorem, jeśli jest to konieczne
        } else if (RedrawChaptersOnly) {
             safeDrawChapterMarkers(); // Tylko odśwież znaczniki z nowym kolorem
        } else if (UpdateStylesOnly) {
            updateStyles(); // Zaktualizuj tylko style CSS paska (niekoniecznie znaczników, chyba że wysokość się zmieniła)
        }
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeExtension);
  } else {
    initializeExtension();
  }
})();