(function() {
  'use strict';

  let options = {
    enabled: true,
    progressColor: '#F76400',
    progressOpacity: 1,
    bufferColor: '#808080',
    bufferOpacity: 1,
    unbufferedColor: '#000000',
    unbufferedOpacity: 1,
    barHeight: 3,
    zIndex: 60,
    chaptersEnabled: true,
    chapterMarkerColor: '#FFFFFF' // Default value, will be overwritten by chrome.storage.sync.get
  };

  let customBar, progressBar, bufferBar, unbufferedBar;
  let chapterMarkersContainer;
  let currentVideoIdForChapters = null;

  function loadOptions(callback) {
    chrome.storage.sync.get(options, function(items) {
      if (chrome.runtime.lastError) {
        console.warn('YTPB: Error loading options:', chrome.runtime.lastError.message);
        // Use default options if loading fails
      } else {
        options = items; // Overwrite the entire options object
      }
      if (callback) callback();
    });
  }

  function createProgressBar() {
    const player = document.querySelector('.html5-video-player');
    if (!player) return;

    if (customBar) {
        removeProgressBar(); // Should not happen if logic is correct, but good for safety
    }

    customBar = document.createElement('div');
    customBar.id = 'custom-progress-bar';

    progressBar = document.createElement('div');
    progressBar.id = 'custom-progress';

    bufferBar = document.createElement('div');
    bufferBar.id = 'custom-buffer';

    unbufferedBar = document.createElement('div');
    unbufferedBar.id = 'custom-unbuffered';

    customBar.appendChild(unbufferedBar);
    customBar.appendChild(bufferBar);
    customBar.appendChild(progressBar);

    if (options.chaptersEnabled) {
        createChapterMarkersContainer(); // Will be appended to customBar
    }
    player.appendChild(customBar);
    updateStyles();
  }

  function removeProgressBar() {
    if (customBar) {
      customBar.remove();
      customBar = null;
      progressBar = null;
      bufferBar = null;
      unbufferedBar = null;
      chapterMarkersContainer = null; // Also remove reference to chapter container
    }
  }

  function updateProgressBar() {
    // This function is only called if options.enabled is true AND customBar exists
    if (!options.enabled || !customBar) {
      return;
    }
    const player = document.querySelector('.html5-video-player');
    if (!player) return;
    const video = player.querySelector('video');
    if (!video || isNaN(video.duration) || video.duration === 0) return;

    const progress = (video.currentTime / video.duration) * 100;
    if (progressBar) progressBar.style.width = `${progress}%`;

    if (video.buffered.length > 0) {
      const bufferedTime = video.buffered.end(video.buffered.length - 1);
      const bufferedPercent = (bufferedTime / video.duration) * 100;
      if (bufferBar) bufferBar.style.width = `${bufferedPercent}%`;
    }
    requestAnimationFrame(updateProgressBar);
  }

  function createChapterMarkersContainer() {
    if (!customBar || chapterMarkersContainer) return; // Must have customBar, must not have existing markers container

    chapterMarkersContainer = document.createElement('div');
    chapterMarkersContainer.id = 'custom-chapter-markers';
    // Styles will be applied/updated in updateStyles or drawChapterMarkersLogic
    customBar.appendChild(chapterMarkersContainer);
  }

  function drawChapterMarkersLogic(description, durationSeconds) {
    if (!options.chaptersEnabled || !customBar) {
        if (chapterMarkersContainer) chapterMarkersContainer.innerHTML = '';
        return;
    }
    if (!chapterMarkersContainer) { // Should have been created by createProgressBar if chapters enabled
        createChapterMarkersContainer();
    }
    if (!chapterMarkersContainer) return; // Still no container, bail.

    chapterMarkersContainer.innerHTML = ''; // Clear previous markers

    // Apply styles here as well, as it might be called independently or options affecting it changed
    chapterMarkersContainer.style.cssText = `
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: ${options.barHeight}px;
        pointer-events: none;
        z-index: ${(parseInt(options.zIndex) || 0) + 3};
    `;

    if (!description || !durationSeconds || durationSeconds === 0) {
        return;
    }

    const lines = description.split('\n');
    const regex = /((?<h>\d{0,2}):)?(?<m>\d{1,2}):(?<s>\d{2})/;
    const chapterTimestamps = [];

    for (const line of lines) {
        const match = line.match(regex);
        if (match && match.groups) {
            const timestampEndIndex = match.index + match[0].length;
            const potentialChapterTitle = line.substring(timestampEndIndex).trim();
            // Ensure it's a chapter title, not just a timestamp or number
            if (potentialChapterTitle.length > 0 && !/^\d/.test(potentialChapterTitle)) {
                 chapterTimestamps.push(match.groups);
            }
        }
    }

    if (chapterTimestamps.length === 0) return;

    const convertToSeconds = (timeObject) => {
        const h = parseInt(timeObject.h) || 0;
        const m = parseInt(timeObject.m) || 0;
        const s = parseInt(timeObject.s) || 0;
        return h * 3600 + m * 60 + s;
    };

    for (const timeObject of chapterTimestamps) {
        const chapterTimeSeconds = convertToSeconds(timeObject);
        const percent = (chapterTimeSeconds / durationSeconds) * 100;
        if (chapterTimeSeconds === 0 || isNaN(percent) || percent <= 0 || percent >= 100) { // Skip 0:00 and invalid
            continue;
        }
        const marker = document.createElement('div');
        marker.className = 'custom-chapter-marker';
        marker.style.cssText = `
            position: absolute;
            left: ${percent}%;
            top: 0;
            width: 2px; /* Fixed width for markers */
            height: 100%;
            background-color: ${options.chapterMarkerColor};
            transform: translateX(-50%); /* Center the marker */
        `;
        chapterMarkersContainer.appendChild(marker);
    }
  }

  window.addEventListener('message', function(event) {
      if (event.source === window && event.data && event.data.type === 'FROM_PAGE_SCRIPT_CHAPTER_DATA_YTPB') {
          const { description, durationSeconds, videoId } = event.data;
          // Check if data is for the current video or if chapters are enabled and bar exists
          if (options.enabled && options.chaptersEnabled && customBar && description && typeof durationSeconds !== 'undefined') {
              // Avoid redrawing for same video unless explicitly needed, though injector sends on request
              // currentVideoIdForChapters could be used for more sophisticated caching if injector sent less often
              currentVideoIdForChapters = videoId;
              drawChapterMarkersLogic(description, parseFloat(durationSeconds));
          }
      }
  });

  function safeDrawChapterMarkers() {
    if (!options.chaptersEnabled || !options.enabled || !customBar) { // Bar must exist
         if (chapterMarkersContainer) chapterMarkersContainer.innerHTML = '';
        return;
    }
    // const playerElement = document.querySelector('.html5-video-player'); // Not strictly needed here
    // if (!playerElement) return;

    try {
      window.postMessage({ type: 'REQUEST_CHAPTER_DATA_YTPB_FROM_CONTENT' }, '*');
    } catch (e) {
      console.warn('YTPB ContentScript: Could not post message to request chapter data.', e);
    }
  }

  function checkAndAddProgressBar() {
    // This function is the main entry point for UI updates based on `options.enabled`
    const player = document.querySelector('.html5-video-player');

    if (options.enabled) {
      if (!player) { // No player, ensure bar is removed if it somehow exists
          if (customBar) removeProgressBar();
          return;
      }
      // Player exists
      if (!customBar || !player.contains(customBar)) { // If bar doesn't exist or not in player
        createProgressBar(); // Creates bar, appends to player, calls updateStyles
      } else {
        updateStyles(); // Bar exists, just ensure styles are current (e.g. after options change)
      }
      updateProgressBar(); // Starts/continues animation frame for progress
      if (options.chaptersEnabled) {
        safeDrawChapterMarkers(); // Request and draw chapter markers
      } else {
        if (chapterMarkersContainer) chapterMarkersContainer.innerHTML = ''; // Clear markers if disabled
      }
    } else { // options.enabled is false
      removeProgressBar();
    }
  }

  function toHex(opacity) {
    const hex = Math.round(opacity * 255).toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }

  function updateStyles() {
    if (!customBar) return; // Cannot update styles if bar doesn't exist

    // Main custom bar container
    customBar.style.cssText = `
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: ${options.barHeight}px;
      z-index: ${options.zIndex};
      display: ${options.enabled ? 'block' : 'none'}; /* Controlled by options.enabled */
    `;

    // Progress part
    if (progressBar) {
      progressBar.style.cssText = `
        width: ${progressBar.style.width || '0%'}; /* Preserve current width */
        height: 100%;
        background-color: ${options.progressColor + toHex(options.progressOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${(parseInt(options.zIndex) || 0) + 2};
      `;
    }

    // Buffer part
    if (bufferBar) {
      bufferBar.style.cssText = `
        width: ${bufferBar.style.width || '0%'}; /* Preserve current width */
        height: 100%;
        background-color: ${options.bufferColor + toHex(options.bufferOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${(parseInt(options.zIndex) || 0) + 1};
      `;
    }

    // Unbuffered (background) part
    if (unbufferedBar) {
      unbufferedBar.style.cssText = `
        width: 100%;
        height: 100%;
        background-color: ${options.unbufferedColor + toHex(options.unbufferedOpacity)};
        position: absolute;
        top: 0;
        left: 0;
        z-index: ${parseInt(options.zIndex) || 0};
      `;
    }

    // Chapter markers container styles (height, z-index are main ones here)
    if (chapterMarkersContainer) {
        chapterMarkersContainer.style.height = `${options.barHeight}px`;
        chapterMarkersContainer.style.zIndex = (parseInt(options.zIndex) || 0) + 3;
        // Actual markers are redrawn by drawChapterMarkersLogic if color changes
    }
  }

  function initializeExtension() {
    loadOptions(function() {
      // Observe for player appearing/disappearing
      const pageObserver = new MutationObserver(mutations => {
        // A bit crude, but re-check whenever mutations occur.
        // checkAndAddProgressBar handles player existence internally.
        checkAndAddProgressBar();
      });
      pageObserver.observe(document.body, {
        childList: true,
        subtree: true
      });

      // Handle YouTube's SPA navigation
      document.addEventListener('yt-navigate-finish', () => {
        currentVideoIdForChapters = null; // Reset video ID for chapters
        if (chapterMarkersContainer) {
            chapterMarkersContainer.innerHTML = ''; // Clear old markers visually
        }
        checkAndAddProgressBar(); // Re-evaluate on new "page"
      });

      // Initial check
      checkAndAddProgressBar();
    });
  }

  chrome.storage.onChanged.addListener(function(changes, namespace) {
    if (namespace === 'sync') {
        let RerenderAll = false;
        let RedrawChaptersOnly = false;
        let UpdateStylesOnly = false;

        for (let key in changes) {
            if (options.hasOwnProperty(key)) {
                options[key] = changes[key].newValue; // Update local options object

                if (key === 'enabled') {
                    RerenderAll = true; // This will call checkAndAddProgressBar
                } else if (key === 'chaptersEnabled') {
                    if (options.enabled) RerenderAll = true; // Needs full re-evaluation
                } else if (key === 'chapterMarkerColor') {
                    if (options.enabled && options.chaptersEnabled) RedrawChaptersOnly = true;
                } else { // Other style changes (colors, height, opacity, zIndex)
                    if (options.enabled) UpdateStylesOnly = true;
                }
            }
        }

        if (RerenderAll) { // Typically when 'enabled' or 'chaptersEnabled' changes
            checkAndAddProgressBar();
        } else if (RedrawChaptersOnly) { // Only chapter marker color changed
            if (options.enabled && options.chaptersEnabled && customBar) { // Ensure bar exists
                 safeDrawChapterMarkers(); // This will re-request and redraw with new color
            }
        } else if (UpdateStylesOnly) { // Only bar styles changed
            if (options.enabled && customBar) { // Ensure bar exists
                updateStyles();
                // If bar height changed, chapter markers also need their height updated
                if (changes.barHeight && options.chaptersEnabled && chapterMarkersContainer) {
                    chapterMarkersContainer.style.height = `${options.barHeight}px`;
                }
            }
        }
    }
  });

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeExtension);
  } else {
    initializeExtension();
  }
})();