document.addEventListener('DOMContentLoaded', function() {
  const enabled = document.getElementById('enabled');
  const progressColor = document.getElementById('progressColor');
  const progressOpacity = document.getElementById('progressOpacity');
  const bufferColor = document.getElementById('bufferColor');
  const bufferOpacity = document.getElementById('bufferOpacity');
  const unbufferedColor = document.getElementById('unbufferedColor');
  const unbufferedOpacity = document.getElementById('unbufferedOpacity');
  const barHeight = document.getElementById('barHeight');
  const zIndex = document.getElementById('zIndex');
  const chaptersEnabled = document.getElementById('chaptersEnabled');
  const chapterMarkerColor = document.getElementById('chapterMarkerColor'); // NOWY ELEMENT

  const defaultOptions = {
    enabled: true,
    progressColor: '#F76400',
    progressOpacity: 1,
    bufferColor: '#808080',
    bufferOpacity: 1,
    unbufferedColor: '#000000',
    unbufferedOpacity: 1,
    barHeight: 3,
    zIndex: 60,
    chaptersEnabled: true,
    chapterMarkerColor: '#FFFFFF' // Domyślny kolor znaczników (biały)
  };

  let saveTimeout = null;

  function loadOptions() {
    chrome.storage.sync.get(defaultOptions, function(items) {
      enabled.checked = items.enabled;
      progressColor.value = items.progressColor;
      progressOpacity.value = items.progressOpacity;
      bufferColor.value = items.bufferColor;
      bufferOpacity.value = items.bufferOpacity;
      unbufferedColor.value = items.unbufferedColor;
      unbufferedOpacity.value = items.unbufferedOpacity;
      barHeight.value = items.barHeight;
      zIndex.value = items.zIndex;
      chaptersEnabled.checked = items.chaptersEnabled;
      chapterMarkerColor.value = items.chapterMarkerColor; // WCZYTAJ KOLOR ZNACZNIKÓW
    });
  }

  function debounce(func, wait) {
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(saveTimeout);
        func(...args);
      };
      clearTimeout(saveTimeout);
      saveTimeout = setTimeout(later, wait);
    };
  }

  const saveOptions = debounce(function() {
    const optionsToSave = {
      enabled: enabled.checked,
      progressColor: progressColor.value,
      progressOpacity: parseFloat(progressOpacity.value),
      bufferColor: bufferColor.value,
      bufferOpacity: parseFloat(bufferOpacity.value),
      unbufferedColor: unbufferedColor.value,
      unbufferedOpacity: parseFloat(unbufferedOpacity.value),
      barHeight: parseInt(barHeight.value),
      zIndex: parseInt(zIndex.value),
      chaptersEnabled: chaptersEnabled.checked,
      chapterMarkerColor: chapterMarkerColor.value // ZAPISZ KOLOR ZNACZNIKÓW
    };
    chrome.storage.sync.set(optionsToSave);
  }, 300);

  loadOptions();

  const allInputs = document.querySelectorAll('input');
  allInputs.forEach(input => {
    input.addEventListener('change', saveOptions);
    if (input.type === 'range' || input.type === 'number' || input.type === 'color') { // Dodano input.type === 'color'
      input.addEventListener('input', saveOptions);
    }
  });
});